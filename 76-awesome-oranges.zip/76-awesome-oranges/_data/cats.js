import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const themes = JSON.parse(readFileSync(join(__dirname, "themes.json"), "utf8"));

const tagCounts = {};
for (const t of themes) {
  for (const tag of t.cats || []) {
    tagCounts[tag] = (tagCounts[tag] || 0) + 1;
  }
}

const sorted = Object.keys(tagCounts).sort();
const byTag = {};
for (const tag of sorted) {
  byTag[tag] = themes.filter((t) => (t.cats || []).includes(tag));
}

export default {
  all: sorted,
  counts: tagCounts,
  byTag,
};
