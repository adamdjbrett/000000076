import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const themes = JSON.parse(readFileSync(join(__dirname, "themes.json"), "utf8"));

const real = themes.filter((t) => !t.placeholder);
const withDemo = real.filter((t) => t.demo);
const totalStars = real.reduce((n, t) => n + (t.stars || 0), 0);
const allTags = new Set();
for (const t of themes) for (const tag of t.cats || []) allTags.add(tag);

export default {
  total: themes.length,
  real: real.length,
  withDemo: withDemo.length,
  totalStars,
  tagCount: allTags.size,
  featured: withDemo.slice(0, 6),
};
