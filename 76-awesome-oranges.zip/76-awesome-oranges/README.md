---
permalink: false
---
# 76 Awesome Oranges

A hand-picked directory of 76 Eleventy (11ty) themes by [Adam DJ Brett](https://adamdjbrett.com), built with the [BuildAwesome starter](https://github.com/buildawesome-one/starter) + [Blades CSS](https://blades.ninja/) + a warm citrus overlay.

- Site: <https://000000076.xyz/>
- Author: Adam DJ Brett

## What's inside

- 72 real `adamdjbrett/11ty-*` themes with metadata (stars, forks, topics, tags)
- 4 placeholder slots to reach 76 (edit `_data/themes.json` to fill in)
- Home, `/themes/` (filterable grid), `/tags/`, per-theme pages, About
- Custom citrus palette layered on Blades CSS (inlined in `.build/_includes/default.njk`)

## Local development

```bash
cd .build
npm install
npm run build     # writes to .build/_site
npx serve _site   # or your preferred static server
```

Node 22.15+ required.

## Structure

```
├── .build/                  BuildAwesome + Eleventy config (needs Node ≥22)
│   ├── _includes/default.njk   base layout (inlined CSS + JS)
│   └── package.json            site globals, styles list
├── _data/
│   ├── themes.json          76 theme records
│   ├── cats.js              computed tag data (renamed from tags.js — Eleventy collision)
│   └── stats.js             computed totals
├── _public/                 passthrough files (css/, js/, favicon.svg)
├── themes/index.njk         filterable /themes/ grid
├── themes/theme.njk         paginated per-theme page → /themes/<slug>/
├── tags/index.njk           /tags/ grouped
├── index.njk                home page
└── about.njk
```

## Deploying to 000000076.xyz

- The build output at `.build/_site/` is a plain static site — deploy anywhere (Netlify, Cloudflare Pages, GitHub Pages, Vercel, S3).
- Absolute paths (`/css/…`, `/themes/…`) work at the site root; if you deploy under a subpath, set Eleventy's `pathPrefix` or serve at root.

## License

MIT. See `LICENSE.md`.
